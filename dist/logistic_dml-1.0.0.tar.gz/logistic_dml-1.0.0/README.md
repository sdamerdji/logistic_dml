# logistic_dml
Python implementation of "Double/Debiased Machine Learning for Logistic Partially Linear Model" by Molei Liu, Yi Zhang and Doudou Zhou. See https://academic.oup.com/ectj/article/24/3/559/6296639

